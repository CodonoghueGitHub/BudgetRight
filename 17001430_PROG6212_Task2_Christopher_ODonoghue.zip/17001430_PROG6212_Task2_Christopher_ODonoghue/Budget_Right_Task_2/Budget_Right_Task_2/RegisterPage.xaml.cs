﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Budget_Right_Task_2
{
    /// <summary>
    /// Interaction logic for RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : Window
    {
        string username, password, confirmPassword, passwordHash;
        string grossMonthly, tax;
        int income, deductions;

       

        private void previewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^0-9]+").IsMatch(e.Text);
        }

        string connectionString = "Data Source=localhost;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public RegisterPage()
        {
            InitializeComponent();
        }

        private void OnclickSignUp(object sender, RoutedEventArgs e)
        {
            progressBar.Visibility = Visibility.Visible;
            username = rUsername.Text.ToString();
            password = rPassword.Password.ToString();
            confirmPassword = cPassword.Password.ToString();
            grossMonthly = GrossIncome.Text.ToString();
            tax = Tax.Text.ToString();
            income = int.Parse(grossMonthly);
            deductions = int.Parse(tax);
            MD5 Md5Pass = MD5.Create();                                 //Create instance of Md5 hash algorithm
            byte[] sourceBytes = Encoding.UTF8.GetBytes(password);  //Get bytes of user input to get bytes of hash value
            byte[] hasbytes = Md5Pass.ComputeHash(sourceBytes);
            passwordHash = BitConverter.ToString(hasbytes).Replace("-", string.Empty);

            SqlConnection regCon = new SqlConnection(connectionString);
            string commandString = "USE guiderightdata INSERT INTO users(Username,UserPassword) Values('"+username+"','"+passwordHash+"');";
            string commandString2 = "USE guiderightdata INSERT INTO userdata(Username,Income,Tax_Deduction,Groceries,Water_Lights,Travel,Phone,Other,RentOrHouse,Car,Remaining) Values('"+username+"','" + income + "','" + deductions + "','0','0','0','0','0','0','0','0');";

            if (password == confirmPassword)
            {
                if (!username.Equals("") && !password.Equals("") && !(int.Parse(tax).Equals("")) && !(int.Parse(grossMonthly).Equals("")))
                {
                    try
                    {
                        using (regCon)
                        {
                            regCon.Open();
                            using (var command = new SqlCommand(commandString, regCon))
                            {
                                command.ExecuteNonQuery();
                            }
                            using (var command2 = new SqlCommand(commandString2, regCon))
                            {
                                command2.ExecuteNonQuery();
                            }
                        }
                    MessageBox.Show("Register Successful");
                    MainWindow login = new MainWindow();
                    login.Show();
                    this.Hide();
                    }
                    catch (SqlException)
                {
                    MessageBox.Show("Username Already Taken");
                    rUsername.Text = "";
                }
            }
            else
                {
                    progressBar.Visibility = Visibility.Hidden;
                    MessageBox.Show("Please enter all fileds");
                }
            }
            else
            {
                progressBar.Visibility = Visibility.Hidden;
                MessageBox.Show("Passwords Do Not Match!");
            }


        }


        private void OnClosed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
