﻿using BudgetRightFunctions;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Budget_Right_Task_2
{
   
    public partial class BuyAProperty : Window
    {
        SqlConnection myConSql = new SqlConnection("Data Source=localhost;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public string user = MainWindow.LoggedInUser;
        public static double dashAnswer;
        public static int answer, pp, dep, intre, months;
        public BuyAProperty()
        {
            InitializeComponent();
        }

        private void previewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^0-9]+").IsMatch(e.Text);
        }

        private void OnClick_CalculateProperty(object sender, RoutedEventArgs e)
        {
            progressBar.Visibility = Visibility.Visible;
            int principle, intrestFormat, years;
            pp = int.Parse(purchasePFig.Text.ToString());
            dep = int.Parse(depositPaid.Text.ToString());
            intre = int.Parse(IntrestRate.Text.ToString());
            months = int.Parse(timePeriod.Text.ToString());

            principle = pp - dep;
            intrestFormat = intre / 100;
            years = months / 12;

            Functions calc = new Functions();

            double answer1 = Math.Round((calc.CalculateHomeLoan(principle,intrestFormat,years)),0);
            answer = (int) answer1;
            remainingLabel.Content = answer;
            dashAnswer = Double.Parse(remainingLabel.Content.ToString());

            double income = Dashboard.userIncome;

            double check = 0.33 * income;
            if (answer > check)
            {
                MessageBox.Show("You cannot afford this House!");
                progressBar.Visibility = Visibility.Hidden;
            }
            else
            {
                MessageBox.Show("You can Afford this!");
                progressBar.Visibility = Visibility.Hidden;
            }

        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            progressBar.Visibility = Visibility.Hidden;
            progressBar1.Visibility = Visibility.Hidden;
        }

        private void OnClick_TryAgain(object sender, RoutedEventArgs e)
        {
            purchasePFig.Text = "0";
            depositPaid.Text = "0";
            IntrestRate.Text = "0";
            timePeriod.Text = "0";
            remainingLabel.Content = "0";
        }

        private void OnClick_To_Dash(object sender, RoutedEventArgs e)
        {
            Dashboard dash = new Dashboard();
            dash.Show();
            this.Hide();
        }

        private void OnClick_Save_ToBudget(object sender, RoutedEventArgs e)
        {
            progressBar1.Visibility = Visibility.Visible;
            string Updatedata = "USE [guiderightdata] UPDATE  userdata SET RentOrHouse='" + dashAnswer + "' WHERE Username = '" + user + "'";

            if (myConSql.State == System.Data.ConnectionState.Closed)
            {
                myConSql.Open();
            }

            using (var cmdUpdate = new SqlCommand(Updatedata, myConSql))
            {
                cmdUpdate.ExecuteNonQuery();
            }
            Dashboard dash1 = new Dashboard();
            dash1.HouseOrRent.Content = "House Repayments:";
            dash1.TotalDisplay.Content = "Amount";
            dash1.remainderDisplay.Content = "Amount";
            dash1.Show();
            this.Close();
        }

        private void OnClosed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
