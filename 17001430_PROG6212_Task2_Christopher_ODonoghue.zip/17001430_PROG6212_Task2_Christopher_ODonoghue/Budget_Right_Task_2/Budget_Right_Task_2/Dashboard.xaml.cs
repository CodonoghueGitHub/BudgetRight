﻿using BudgetRightFunctions;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Budget_Right_Task_2
{
    /// <summary>
    /// Interaction logic for Dashboard.xaml
    /// </summary>
    public partial class Dashboard : Window
    {
        public string user = MainWindow.LoggedInUser;
        double rent;
        public static double userIncome, deducted, startAmount, a, b, c, d, ee, f, g;
        double totalExpenses,remainder;
        SqlConnection myConSql = new SqlConnection("Data Source=localhost;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

        public Dashboard()
        {
            InitializeComponent();
        }

        private void On_Loaded(object sender, RoutedEventArgs e)
        {
            progressBar1.Visibility = Visibility.Hidden;
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            if (myConSql.State == System.Data.ConnectionState.Closed)
            {
                myConSql.Open();
            }

            string query = "USE guiderightdata SELECT Income,Tax_Deduction,Groceries,Water_Lights,Travel,Phone,Other,RentOrHouse,Car,Remaining FROM userdata WHERE Username ='" + user + "'";
            SqlCommand sqlCmd = new SqlCommand(query,myConSql);
            SqlDataReader dr = sqlCmd.ExecuteReader();
            while (dr.Read())
            {
                IncomeDisplay.Text = dr.GetValue(0).ToString();
                userIncome = int.Parse(dr.GetValue(0).ToString());
                TaxDisplay.Text = dr.GetValue(1).ToString();
                GroceriesDisplay.Text = dr.GetValue(2).ToString();
                wAndL.Text = dr.GetValue(3).ToString();
                travelDisplay.Text = dr.GetValue(4).ToString();
                phoneDisplay.Text = dr.GetValue(5).ToString();
                otherDisplay.Text = dr.GetValue(6).ToString();
                RentDisplay.Content = dr.GetValue(7).ToString();
                carDisplay.Content = dr.GetValue(8).ToString();

            }

            rentQuestionLabel.Visibility = Visibility.Hidden;
            rentAmount.Visibility = Visibility.Hidden;
            addRent.Visibility = Visibility.Hidden;

        }

        private void purchaseVehBtn(object sender, RoutedEventArgs e)
        {
            BuyACar carBuy = new BuyACar();
            carBuy.Show();
            this.Hide();
        }

        private void EnterRentBtn(object sender, RoutedEventArgs e)
        {
            rentQuestionLabel.Visibility = Visibility.Visible;
            rentAmount.Visibility = Visibility.Visible;
            addRent.Visibility = Visibility.Visible;
        }

        private void purchasePropBtn(object sender, RoutedEventArgs e)
        {
            
            BuyAProperty property = new BuyAProperty();
            property.Show();
            this.Hide();
        }

        private void OnClosed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void OnClick_AddRent(object sender, RoutedEventArgs e)
        {
            rent = int.Parse(rentAmount.Text.ToString());
            HouseOrRent.Content = "Rent";
            RentDisplay.Content = rent.ToString();
            rentQuestionLabel.Visibility = Visibility.Hidden;
            rentAmount.Visibility = Visibility.Hidden;
            addRent.Visibility = Visibility.Hidden;
            Calculate();
        }

       public void Calculate()
        {
          
            a = Double.Parse(GroceriesDisplay.Text.ToString());
            b = Double.Parse(wAndL.Text.ToString());
            c = Double.Parse(travelDisplay.Text.ToString());
            d = Double.Parse(phoneDisplay.Text.ToString());                                                            //Retrieving all user edited values from window
            ee = Double.Parse(otherDisplay.Text.ToString());
            f = Double.Parse(RentDisplay.Content.ToString());
            g = Double.Parse(carDisplay.Content.ToString());

            Functions calc = new Functions();
            totalExpenses = Math.Round(calc.CalculateExpenses(a, b, c, d, ee, f, g));

            TotalDisplay.Content = totalExpenses;
        }

        private void previewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^0-9]+").IsMatch(e.Text);
        }

        private void OnClick_Save_Calculate(object sender, RoutedEventArgs e)
        {
            progressBar1.Visibility = Visibility.Visible;
            userIncome = int.Parse(IncomeDisplay.Text.ToString());
            deducted = int.Parse(TaxDisplay.Text.ToString());
            startAmount = userIncome - deducted;
            Calculate();
            remainder = startAmount - totalExpenses;
            remainderDisplay.Content = remainder;
            sqlUpdate();
            progressBar1.Visibility = Visibility.Hidden;

        }

        private void sqlUpdate()
        {
            string Updatedata = "UPDATE  userdata SET Income='"+userIncome+"',Tax_Deduction='"+deducted+ "',Groceries='" + a + "',Water_Lights='" + b + "',Travel='" + c +"',Phone='" + d + "',Other='" + ee + "',RentOrHouse='" + f + "',Car='" + g + "',Remaining='"+remainder+"' WHERE Username ='"+user+"'";

            using (var cmdUpdate = new SqlCommand(Updatedata, myConSql))
            {
                cmdUpdate.ExecuteNonQuery();
            }

        }
    }
}
