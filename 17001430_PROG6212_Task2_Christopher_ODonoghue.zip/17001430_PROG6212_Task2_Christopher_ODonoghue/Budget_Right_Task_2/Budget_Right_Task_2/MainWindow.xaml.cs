﻿using Microsoft.Win32;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Budget_Right_Task_2
{

    public partial class MainWindow : Window
    {
        //Connection String for each machine will need to change the connection string to connect to a database

        string connectionString = "Data Source=localhost;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        SqlConnection myConSql = new SqlConnection("Data Source=localhost;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public static string LoggedInUser;

        public MainWindow()
        {
            InitializeComponent();
            createDatabase();
        }

        private void createDatabase()
        {
            string path = "sqlSetup.txt";
            string script = File.ReadAllText(path);

            // split script on GO command
            System.Collections.Generic.IEnumerable<string> commandStrings = Regex.Split(script, @"^\s*GO\s*$",
                                     RegexOptions.Multiline | RegexOptions.IgnoreCase);
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                foreach (string commandString in commandStrings)
                {
                    if (commandString.Trim() != "")
                    {
                        using (var command = new SqlCommand(commandString, connection))
                        {
                            try
                            {
                                command.ExecuteNonQuery();
                            }
                            catch (SqlException ex)
                            {
                                string spError = commandString.Length > 100 ? commandString.Substring(0, 100) + " ...\n..." : commandString;
                                MessageBox.Show(string.Format("Please check the SqlServer script.\nFile: {0} \nLine: {1} \nError: {2} \nSQL Command: \n{3}", path, ex.LineNumber, ex.Message, spError), "Warning", MessageBoxButton.OK);
                            }
                        }
                    }
                }
                connection.Close();

            }
        }

            private void OnclickLoginBtn(object sender, RoutedEventArgs e)
            {
                string userName = username.Text;
                string pass, triedPassHash;
                pass = password.Password.ToString();

                //Generate MD5 string for data storage
                MD5 Md5Pass = MD5.Create();                                 //Create instance of Md5 hash algorithm
                byte[] sourceBytes = Encoding.UTF8.GetBytes(pass);  //Get bytes of user input to get bytes of hash value
                byte[] hasbytes = Md5Pass.ComputeHash(sourceBytes);
                triedPassHash = BitConverter.ToString(hasbytes).Replace("-", string.Empty);


                string myQuery;
                myQuery = "USE guiderightdata SELECT COUNT(*) FROM users WHERE Username='"+userName+"' AND UserPassword='"+triedPassHash+"'";
                if (myConSql.State == ConnectionState.Closed)
                {
                    myConSql.Open();
                }

                SqlCommand sqlCmd = new SqlCommand(myQuery);
                


            try
            {
                    SqlDataAdapter dataAdap = new SqlDataAdapter(myQuery, myConSql);
                    DataTable dataTab = new DataTable();
                    dataAdap.Fill(dataTab);
                    string rows = dataTab.Rows.Count.ToString();
                    if (dataTab.Rows[0][0].ToString() == "1") 
                    {
                        LoggedInUser = userName;
                        Dashboard dash = new Dashboard();
                        dash.Show();
                        this.Hide();
                    }
                else
                    {
                        MessageBox.Show("Incorrect Username or Password " + dataTab.Rows[0][0].ToString());
                    }

                

                
            }
            catch (SqlException)
            {
                string spError = myQuery.Length > 100 ? myQuery.Substring(0, 100) + " ...\n..." : myQuery;
                MessageBox.Show("Please check the SqlServer script.");
            }
            
        }

            private void OnClickRegisterLink(object sender, RoutedEventArgs e)
            {
            RegisterPage Regispg = new RegisterPage();
            Regispg.Show();
            this.Hide();
            }
        }
    } 
