﻿using BudgetRightFunctions;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Budget_Right_Task_2
{
    public partial class BuyACar : Window
    {
        SqlConnection myConSql = new SqlConnection("Data Source=localhost;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public string user = MainWindow.LoggedInUser;
        public static string carType;

        public static double CarPrice;
        public BuyACar()
        {
            InitializeComponent();
        }

        private void previewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^0-9]+").IsMatch(e.Text);
        }

        private void OnClick_CalculateCar(object sender, RoutedEventArgs e)
        {
            progressBar1.Visibility = Visibility.Visible;
            carType = carMake.Text.ToString();
            Functions calCar = new Functions();
            double pp, td, intrest, intrestFormat,insurance;
            pp = Double.Parse(purchasePCar.Text.ToString());
            td = Double.Parse(depositPaidCar.Text.ToString());
            intrest = Double.Parse(IntrestRateCar.Text.ToString());
            intrestFormat = intrest / 100;
            insurance = Double.Parse(insurancePrice.Text.ToString());

            

            double presentValue = pp - td;
            CarPrice = Math.Round(calCar.CalculateCarPay(presentValue, intrestFormat));
            CarMonthlyRepay.Content = CarPrice;
            progressBar1.Visibility = Visibility.Hidden;

        }

        private void OnClick_TryAgain(object sender, RoutedEventArgs e)
        {
            purchasePCar.Text = "0";
            depositPaidCar.Text = "0";
            IntrestRateCar.Text = "0";
            insurancePrice.Text = "0";
            CarMonthlyRepay.Content = "0";
            
        }

        private void OnClick_To_Dash(object sender, RoutedEventArgs e)
        {
            Dashboard dash = new Dashboard();
            dash.Show();
            this.Hide();
        }

        private void OnClick_Save_ToBudget(object sender, RoutedEventArgs e)
        {
            progressBar.Visibility = Visibility.Visible;
            string Updatedata = "USE [guiderightdata] UPDATE  userdata SET Car='" + CarPrice + "' WHERE Username = '"+user+"'";

            if (myConSql.State == System.Data.ConnectionState.Closed)
            {
                myConSql.Open();
            }
            using (var cmdUpdate = new SqlCommand(Updatedata, myConSql))
            {
                cmdUpdate.ExecuteNonQuery();
            }
            MessageBox.Show("Successfully added!");
            Dashboard dash1 = new Dashboard();
            dash1.TotalDisplay.Content = "Amount";
            dash1.remainderDisplay.Content = "Amount";
            dash1.carType.Content = carType;
            dash1.Show();
            this.Close();
        }

        private void On_LoadedCar(object sender, RoutedEventArgs e)
        {
            progressBar1.Visibility = Visibility.Hidden;
            progressBar.Visibility = Visibility.Hidden;
        }
    }
}
